(function () {
  const ROOT_ID = "dealer-marketplace-helper";
  const STATUS_ID = "dealer-marketplace-helper-status";
  let autoApplyRunning = false;
  let lastUrl = location.href;

  function normalizeText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function isVisible(node) {
    if (!node || !node.isConnected) return false;
    const style = window.getComputedStyle(node);
    if (style.display === "none" || style.visibility === "hidden") return false;
    return node.getClientRects().length > 0;
  }

  function dispatchMouseSequence(node) {
    if (!node) return false;
    const events = ["pointerdown", "mousedown", "mouseup", "click"];
    node.focus?.();
    for (const type of events) {
      node.dispatchEvent(
        new MouseEvent(type, {
          bubbles: true,
          cancelable: true,
          view: window,
        })
      );
    }
    node.click?.();
    return true;
  }

  function getAriaLabelText(node) {
    const ids = String(node?.getAttribute("aria-labelledby") || "")
      .split(/\s+/)
      .filter(Boolean);
    return normalizeText(
      ids
        .map((id) => document.getElementById(id)?.textContent || "")
        .filter(Boolean)
        .join(" ")
        .toLowerCase()
    );
  }

  function getComboboxValue(node) {
    if (!node) return "";
    const candidates = Array.from(
      node.querySelectorAll('[tabindex="-1"] span, [tabindex="-1"] div, input, textarea, [role="textbox"]')
    )
      .map((candidate) => normalizeText(candidate.textContent || candidate.value || ""))
      .filter(Boolean);
    return candidates[0] || "";
  }

  function collectFieldText(node) {
    return normalizeText(
      [
        getAriaLabelText(node),
        node.getAttribute("aria-label"),
        node.getAttribute("placeholder"),
        node.getAttribute("name"),
        node.id,
        node.closest("label")?.textContent,
        node.closest('[aria-label]')?.getAttribute("aria-label"),
        node.closest('[role="group"]')?.textContent,
        node.previousElementSibling?.textContent,
        node.parentElement?.previousElementSibling?.textContent,
        node.parentElement?.textContent,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()
    );
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function matchesHint(text, hints, exact = false) {
    const source = normalizeText(text).toLowerCase();
    if (!source) return false;
    return hints.some((hint) => {
      const normalizedHint = normalizeText(hint).toLowerCase();
      return exact ? source === normalizedHint || source.startsWith(`${normalizedHint} `) : source.includes(normalizedHint);
    });
  }

  function findLabeledInput(hints, { tagName = "", exact = false } = {}) {
    const labels = Array.from(document.querySelectorAll("label")).filter(isVisible);
    for (const label of labels) {
      const labelText = normalizeText(
        [
          getAriaLabelText(label),
          ...Array.from(label.querySelectorAll("span[id]")).map((node) => node.textContent || ""),
        ].join(" ")
      ).toLowerCase();
      if (!matchesHint(labelText, hints, exact)) continue;
      const target = label.querySelector(tagName ? tagName.toLowerCase() : 'input, textarea, [contenteditable="true"], [role="textbox"]');
      if (target) return target;
    }
    return null;
  }

  function findEditable(hints, { tagName = "", exact = false } = {}) {
    const labeled = findLabeledInput(hints, { tagName, exact });
    if (labeled) return labeled;
    const candidates = Array.from(
      document.querySelectorAll('input, textarea, [contenteditable="true"], [role="textbox"]')
    ).filter((node) => {
      const type = (node.getAttribute("type") || "").toLowerCase();
      if (["hidden", "file", "checkbox", "radio"].includes(type)) return false;
      if (tagName && node.tagName !== tagName.toUpperCase()) return false;
      if (!isVisible(node)) return false;
      return true;
    });
    return candidates.find((node) => {
      const text = collectFieldText(node);
      return matchesHint(text, hints, exact);
    });
  }

  function findDescriptionField() {
    return (
      findEditable(["description"], { tagName: "TEXTAREA", exact: true }) ||
      findEditable(["description"], { tagName: "TEXTAREA" }) ||
      findEditable(["description"], { exact: true }) ||
      findEditable(["description"])
    );
  }

  function findTextField(hints) {
    return findEditable(hints, { exact: true }) || findEditable(hints);
  }

  function findFieldGroupTitle(title) {
    return Array.from(document.querySelectorAll("span, div, h1, h2, h3")).find((node) =>
      isVisible(node) && normalizeText(node.textContent).toLowerCase() === normalizeText(title).toLowerCase()
    );
  }

  function setNativeInputValue(node, value) {
    if (!node) return false;
    const prototype = node.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (!descriptor?.set) return false;
    descriptor.set.call(node, value);
    node.dispatchEvent(new Event("input", { bubbles: true }));
    node.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function setNodeValue(node, value) {
    if (!node || value == null || value === "") return false;
    node.focus();
    if (node.tagName === "TEXTAREA" || node.tagName === "INPUT") {
      const ok = setNativeInputValue(node, value);
      node.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Tab" }));
      return ok;
    }
    if (node.getAttribute("contenteditable") === "true" || node.getAttribute("role") === "textbox") {
      node.textContent = value;
      node.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
      return true;
    }
    return false;
  }

  function findSelectTrigger(hints) {
    const exactCandidates = Array.from(
      document.querySelectorAll('label[role="combobox"], [role="combobox"], [aria-haspopup="listbox"]')
    ).filter(isVisible);
    const exactMatch = exactCandidates.find((node) => matchesHint(getAriaLabelText(node), hints, true));
    if (exactMatch) return exactMatch;
    return exactCandidates.find((node) => matchesHint(collectFieldText(node), hints, false));
  }

  function findOptionByText(values) {
    const targets = (Array.isArray(values) ? values : [values])
      .map((value) => normalizeText(value).toLowerCase())
      .filter(Boolean);
    if (!targets.length) return null;

    const exactCandidates = Array.from(
      document.querySelectorAll('[role="option"], [role="menuitemradio"], [role="menuitem"], [aria-selected="true"], [aria-selected="false"]')
    ).filter(isVisible);
    const broadCandidates = Array.from(document.querySelectorAll("li, span, div"))
      .filter((node) => isVisible(node) && !node.querySelector("input, textarea") && normalizeText(node.textContent).length <= 64);
    const candidates = [...exactCandidates, ...broadCandidates];

    const scored = candidates
      .map((node) => {
        const text = normalizeText(node.textContent).toLowerCase();
        if (!text) return null;
        const score = targets.reduce((best, target) => {
          if (text === target) return Math.max(best, 100);
          if (text.startsWith(target)) return Math.max(best, 80);
          if (text.includes(target)) return Math.max(best, 60);
          return best;
        }, 0);
        return score ? { node, score, textLength: text.length } : null;
      })
      .filter(Boolean)
      .sort((left, right) => right.score - left.score || left.textLength - right.textLength);

    return scored[0]?.node || null;
  }

  function bodyStyleCandidates(value) {
    const source = normalizeText(value || "Sedan").toLowerCase();
    if (source.includes("suv")) return ["SUV", "Sedan"];
    if (source.includes("truck")) return ["Truck", "Pickup Truck", "Sedan"];
    if (source.includes("hatch")) return ["Hatchback", "Sedan"];
    if (source.includes("coupe")) return ["Coupe", "Sedan"];
    if (source.includes("wagon")) return ["Wagon", "Sedan"];
    if (source.includes("convert")) return ["Convertible", "Sedan"];
    if (source.includes("van")) return ["Van", "Minivan", "Sedan"];
    return [normalizeText(value || "Sedan"), "Sedan"];
  }

  function vehicleTypeCandidates() {
    return ["Car/Truck", "Car / Truck", "Cars & Trucks", "Car", "Truck"];
  }

  function isVehicleTypeReady(value) {
    const text = normalizeText(value).toLowerCase();
    return text === "car/truck" || text === "car / truck" || text === "cars & trucks" || text === "car" || text === "truck";
  }

  async function selectOption(hints, value, fallbacks = []) {
    const candidateValues = [value, ...fallbacks].map((item) => normalizeText(item)).filter(Boolean);
    if (!candidateValues.length) return false;
    const trigger = findSelectTrigger(hints);
    if (!trigger) return false;

    const currentValue = normalizeText(getComboboxValue(trigger)).toLowerCase();
    if (candidateValues.some((candidate) => currentValue === candidate.toLowerCase())) {
      return true;
    }

    for (const candidate of candidateValues) {
      dispatchMouseSequence(trigger);
      await wait(450);
      const option = findOptionByText(candidate);
      if (!option) continue;
      dispatchMouseSequence(option);
      await wait(350);
      const nextValue = normalizeText(getComboboxValue(trigger)).toLowerCase();
      if (!nextValue || nextValue.includes(candidate.toLowerCase()) || candidate.toLowerCase().includes(nextValue)) {
        return true;
      }
    }

    return false;
  }

  async function pickVehicleType(value) {
    const trigger = findSelectTrigger(["vehicle type"]);
    if (!trigger) return false;
    const currentValue = normalizeText(getComboboxValue(trigger));
    if (isVehicleTypeReady(currentValue)) {
      return true;
    }
    const candidates = vehicleTypeCandidates();
    const changed = await selectOption(["vehicle type"], candidates[0], candidates.slice(1));
    if (!changed) {
      return false;
    }
    await wait(1100);
    const nextValue = normalizeText(getComboboxValue(findSelectTrigger(["vehicle type"]) || trigger));
    return isVehicleTypeReady(nextValue);
  }

  async function pickBodyStyle(value) {
    const candidates = bodyStyleCandidates(value);
    return await selectOption(["body style"], candidates[0], candidates.slice(1));
  }

  function findAddPhotosButton() {
    return Array.from(document.querySelectorAll('button, [role="button"]')).find((node) =>
      /add photos/i.test(normalizeText(node.textContent || node.getAttribute("aria-label") || ""))
    );
  }

  function findImageInput() {
    return Array.from(document.querySelectorAll('input[type="file"][multiple], input[type="file"]')).find((node) => {
      if (!isVisible(node) && node.closest("label") && !isVisible(node.closest("label"))) return false;
      const accept = String(node.getAttribute("accept") || "").toLowerCase();
      return (!accept || accept.includes("image")) && node.hasAttribute("multiple");
    });
  }

  async function uploadImages(imageUrls) {
    let input = findImageInput();
    if (!input) {
      findAddPhotosButton()?.click();
      await wait(500);
      input = findImageInput();
    }
    if (!input || !Array.isArray(imageUrls) || !imageUrls.length) return { ok: false, uploaded: 0 };
    const dataTransfer = new DataTransfer();
    let uploaded = 0;
    for (let index = 0; index < Math.min(imageUrls.length, 10); index += 1) {
      const url = imageUrls[index];
      try {
        const response = await fetch(url);
        if (!response.ok) continue;
        const blob = await response.blob();
        const extensionMatch = String(url).match(/\.([a-zA-Z0-9]{3,4})(?:[?#]|$)/);
        const extension = extensionMatch?.[1] || "jpg";
        dataTransfer.items.add(new File([blob], `vehicle-${index + 1}.${extension}`, { type: blob.type || `image/${extension}` }));
        uploaded += 1;
      } catch {
        // Ignore individual image failures.
      }
    }
    if (!uploaded) return { ok: false, uploaded: 0 };
    input.files = dataTransfer.files;
    input.dispatchEvent(new Event("click", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.dispatchEvent(new Event("input", { bubbles: true }));
    try {
      input.dispatchEvent(new DragEvent("drop", { bubbles: true, dataTransfer }));
    } catch {
      // DragEvent is not always constructible in Chrome extension contexts.
    }
    await wait(800);
    return { ok: true, uploaded };
  }

  function getStatusNode() {
    return document.getElementById(STATUS_ID);
  }

  function setStatus(lines, tone = "neutral") {
    const node = getStatusNode();
    if (!node) return;
    const colors = {
      neutral: "rgba(255,255,255,0.76)",
      success: "#d6ffe5",
      warning: "#ffe4c7",
      danger: "#ffd1d1",
    };
    node.innerHTML = "";
    lines.forEach((line) => {
      const row = document.createElement("div");
      row.textContent = line;
      row.style.marginTop = "4px";
      node.appendChild(row);
    });
    node.style.color = colors[tone] || colors.neutral;
  }

  async function readDraft() {
    const saved = await chrome.storage.local.get(["dealerDraft"]);
    return saved.dealerDraft || null;
  }

  async function clearAutoApplyFlag() {
    await chrome.storage.local.set({
      dealerAutoApply: {
        pending: false,
        updatedAt: Date.now(),
      },
    });
  }

  async function applyDraft({ auto = false } = {}) {
    const dealerDraft = await readDraft();
    if (!dealerDraft) {
      setStatus(["No draft found.", "Open a Bert Ogden vehicle page and use Quick Post first."], "danger");
      return { ok: false, appliedCount: 0, failedCount: 1 };
    }

    const results = [];
    const vehicle = dealerDraft.vehicle || {};
    const modelValue = normalizeText(vehicle.model || dealerDraft.raw?.model || "");
    const mileageValue = String(vehicle.mileage || "").replace(/[^0-9]/g, "");

    const vehicleTypeOk = await pickVehicleType(vehicle.body_style || "Sedan");
    results.push(vehicleTypeOk ? "Filled vehicle type" : "Could not find vehicle type field");
    if (!vehicleTypeOk) {
      const trigger = findSelectTrigger(["vehicle type"]);
      const currentValue = normalizeText(getComboboxValue(trigger));
      if (!isVehicleTypeReady(currentValue)) {
        setStatus(
          [
            "Facebook vehicle type was not set to Car/Truck.",
            "The rest of the fields were skipped so Facebook does not wipe them afterward.",
            "Open the Vehicle type dropdown first, then click Apply Saved Draft again.",
          ],
          "warning"
        );
        return { ok: false, appliedCount: 0, failedCount: 1 };
      }
    }

    const priceOk = setNodeValue(findTextField(["price", "asking price"]), dealerDraft.price || "");
    results.push(priceOk ? "Filled price" : "Could not find price field");

    const yearOk =
      (await selectOption(["year"], vehicle.year || "")) ||
      setNodeValue(findTextField(["year"]), vehicle.year || "");
    results.push(yearOk ? "Filled year" : "Could not find year field");

    const makeOk =
      (await selectOption(["make"], vehicle.make || "")) ||
      setNodeValue(findTextField(["make"]), vehicle.make || "");
    results.push(makeOk ? "Filled make" : "Could not find make field");

    const modelOk =
      (await selectOption(["model"], modelValue)) ||
      setNodeValue(findTextField(["model"]), modelValue);
    results.push(modelOk ? "Filled model" : "Could not find model field");

    const mileageOk =
      (await selectOption(["mileage", "odometer"], mileageValue)) ||
      setNodeValue(findTextField(["mileage", "odometer"]), mileageValue);
    results.push(mileageOk ? "Filled mileage" : "Could not find mileage field");

    const descOk = setNodeValue(findDescriptionField(), dealerDraft.description || "");
    results.push(descOk ? "Filled description" : "Could not find description field");

    const conditionOk =
      (await selectOption(["condition"], vehicle.condition || "")) ||
      setNodeValue(findTextField(["condition"]), vehicle.condition || "");
    results.push(conditionOk ? "Filled condition" : "Could not find condition field");

    const bodyStyleOk = await pickBodyStyle(vehicle.body_style || "Sedan");
    results.push(bodyStyleOk ? "Filled body style" : "Could not find body style field");

    const warningLines = [];
    if (Array.isArray(dealerDraft.images) && dealerDraft.images.length) {
      const uploadResult = await uploadImages(dealerDraft.images);
      if (uploadResult.ok) {
        results.push(`Queued ${uploadResult.uploaded} photo${uploadResult.uploaded === 1 ? "" : "s"}`);
      } else {
        warningLines.push(`Images found on vehicle page: ${dealerDraft.images.length}`);
        warningLines.push("Photo upload could not be automated on this Facebook layout.");
      }
    }

    const failedCount = results.filter((line) => line.startsWith("Could not")).length;
    const appliedCount = results.length - failedCount;
    const statusLines = auto
      ? ["Auto-fill attempted on Facebook Marketplace.", ...results, ...warningLines]
      : [...results, ...warningLines];

    setStatus(statusLines, failedCount ? "warning" : "success");
    return { ok: appliedCount > 0, appliedCount, failedCount };
  }

  async function maybeAutoApply() {
    if (autoApplyRunning) return;
    const { dealerAutoApply } = await chrome.storage.local.get(["dealerAutoApply"]);
    if (!dealerAutoApply?.pending) return;

    autoApplyRunning = true;
    setStatus(["Saved draft detected.", "Waiting for Facebook's vehicle form..."]);

    try {
      for (let attempt = 0; attempt < 15; attempt += 1) {
        const formReady = Boolean(
          findTextField(["price", "model", "mileage"]) ||
            findDescriptionField() ||
            findSelectTrigger(["vehicle type", "year", "make", "condition"])
        );
        if (formReady) {
          await applyDraft({ auto: true });
          await clearAutoApplyFlag();
          autoApplyRunning = false;
          return;
        }
        await wait(900);
      }

      setStatus(
        [
          "Draft was ready, but Facebook's form did not finish loading in time.",
          "Click Apply Saved Draft below once the page is fully visible.",
        ],
        "warning"
      );
      await clearAutoApplyFlag();
    } finally {
      autoApplyRunning = false;
    }
  }

  function mountPanel() {
    if (document.getElementById(ROOT_ID)) return;
    const root = document.createElement("div");
    root.id = ROOT_ID;
    root.style.position = "fixed";
    root.style.right = "16px";
    root.style.bottom = "16px";
    root.style.zIndex = "999999";
    root.style.background = "rgba(20, 28, 37, 0.96)";
    root.style.color = "white";
    root.style.padding = "12px";
    root.style.borderRadius = "14px";
    root.style.boxShadow = "0 14px 28px rgba(0,0,0,0.28)";
    root.style.fontFamily = "Arial, sans-serif";
    root.style.width = "280px";

    const label = document.createElement("div");
    label.textContent = "Dealer Marketplace Helper";
    label.style.fontSize = "11px";
    label.style.letterSpacing = "0.12em";
    label.style.textTransform = "uppercase";
    label.style.opacity = "0.75";
    label.style.marginBottom = "8px";

    const button = document.createElement("button");
    button.textContent = "Apply Saved Draft";
    button.style.width = "100%";
    button.style.border = "0";
    button.style.borderRadius = "10px";
    button.style.padding = "10px 12px";
    button.style.fontWeight = "700";
    button.style.cursor = "pointer";
    button.style.background = "#d8783a";
    button.style.color = "white";
    button.style.marginBottom = "8px";
    button.addEventListener("click", () => applyDraft({ auto: false }));

    const status = document.createElement("div");
    status.id = STATUS_ID;
    status.style.fontSize = "12px";
    status.style.lineHeight = "1.35";
    status.style.color = "rgba(255,255,255,0.76)";
    status.textContent = "Ready. Quick Post from the vehicle page will try to fill this form automatically.";

    root.appendChild(label);
    root.appendChild(button);
    root.appendChild(status);
    document.body.appendChild(root);
  }

  function handlePageChange() {
    if (!/facebook\.com\/marketplace\//i.test(location.href)) return;
    mountPanel();
    maybeAutoApply();
  }

  if (/facebook\.com\/marketplace\//i.test(location.href)) {
    handlePageChange();

    const observer = new MutationObserver(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
      }
      handlePageChange();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
})();
